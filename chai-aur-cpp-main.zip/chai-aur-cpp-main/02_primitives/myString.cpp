#include <iostream>
#include <string>

using namespace std;

int main(){
    string favoriteTea = "Lemon Tea \t";
    string description = "Known as \"best\" tea";

    cout << favoriteTea << description << endl;

    return 0;
}