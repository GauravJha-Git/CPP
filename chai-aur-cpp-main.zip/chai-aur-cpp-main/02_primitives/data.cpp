#include <iostream>

using namespace std;

int main(){

    int teaLeaves = 50;
    float waterTemperature = 85.588588;
    double priceOfTea = 299.99;
    char teaGrade = 'A';
    bool isTeaReady = false;

    cout << waterTemperature << endl;

    return 0;
}