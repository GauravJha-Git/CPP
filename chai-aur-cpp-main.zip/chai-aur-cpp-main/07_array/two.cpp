#include <iostream>

using namespace std;

int main(){
    int chaiServed[7] = {50, 60, 55, 70, 65, 80, 75};

    cout << "Chai cups served on Day 1: " << chaiServed[0];
    cout << "Chai cups served on Day 2: " << chaiServed[1];

    return 0;
}