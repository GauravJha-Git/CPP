### 1. **If Statement**

### **Challenge:** Write a program that checks if the user wants to order Green Tea. If the user types "Green Tea," the program should confirm their order.

### 2. **If-Else Statement**

### **Challenge:** Write a program that checks if a tea shop is open. If the current hour (input by the user) is between 8 AM and 6 PM, the shop is open; otherwise, it’s closed.

### 3. **Nested If-Else**

### **Challenge:** A tea shop offers discounts based on the number of tea cups ordered. Write a program that checks the number of cups ordered and applies a discount:* More than 20 cups: 20% discount
* Between 10 and 20 cups: 10% discount
* Less than 10 cups: No discount


### 4. **Switch Case**

### **Challenge:** Write a program that lets the user select a tea type from a menu. Use a switch statement to display the price based on the selected tea:* Green Tea: $2
* Black Tea: $3
* Oolong Tea: $4

