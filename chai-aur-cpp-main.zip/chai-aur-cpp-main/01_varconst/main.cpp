#include <iostream>

using namespace std;

int main(){
    
    int score;
    score = 110;

    const int uid = 232323;

    int hiteshBalance = 500;
    hiteshBalance = 1000;

    // uid = 1223;
    cout << "Welcome to chai with cpp 1" << endl ;

    
    cout << "Welcome to chai with cpp 2" << endl ;
    cout << "Welcome to chai with cpp 3" << endl ;

    return 0;
}