# Code files for C++

> Playlist url : [youtube link](https://youtube.com/playlist?list=PLu71SKxNbfoCPfgKZS8UE0MDuwiKvL8zi&si=JtyW06CizjYo7cCh)

Welcome to the C++ playlist. This playlist is a collection of C++ code files that you can use to practice your C++ skills. Each code file is designed to teach a specific concept or technique, and you can use them as a starting point for your own projects.

If you want to follow along with the videos, use the link mentioned above to subscribe to the playlist.

## Raising PR

Please do not raise any PRs for this playlist. Learners should get the playlist exactly what was taught in the videos.

## Social

- [twitter](https://twitter.com/hiteshdotcom)
- [LinkedIn](https://www.linkedin.com/in/hiteshchoudhary/)

## Course link (Udemy)

[One stop web development](https://hitesh.ai/udemy)

## Challenges

I am trying to add challenges to the playlist. Finish these challenges and post code selfie on linkedin and twitter and share it with me.
